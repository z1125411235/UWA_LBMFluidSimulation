unity-lbm-fluid-simulation
=====================

Lattice Boltzmann Method (LBM) fluid simulation for Unity.

![lbm](https://raw.githubusercontent.com/mattatz/unity-lbm-fluid-simulation/master/Captures/lbm.gif)

## Demo

[Unity Web Player](https://mattatz.github.io/unity/lbm-fluid-simulation)
